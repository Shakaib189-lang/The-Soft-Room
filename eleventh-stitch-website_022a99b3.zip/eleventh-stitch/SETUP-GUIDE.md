# Eleventh Stitch — Setup Guide

**Aap ke liye sirf 2 cheezein karni hain: Domain kharidna aur Hosting kharidna.**
Baqi sab kuch (design, code, products, photos, cart, order system, SEO) ban chuka hai.

Ye guide Roman Urdu mein hai. Computer ka bara tajurba zaroori nahi — bas upar se
neeche tak steps follow karte jaiye.

---

## Fehrist (Table of Contents)

**Hissa 1 — Website live karna (ek dafa ka kaam)**
1. [Aap ko kya kya chahiye](#1-aap-ko-kya-kya-chahiye)
2. [Domain kharidna](#2-domain-kharidna)
3. [Hosting kharidna](#3-hosting-kharidna)
4. [Files upload karna](#4-files-upload-karna)
5. [Domain ko hosting se jorna (DNS)](#5-domain-ko-hosting-se-jorna-dns)
6. [SSL lagana — https ka green lock](#6-ssl-lagana--https-ka-green-lock)

**Hissa 2 — Website apni banana (zaroori)**
7. [Apna WhatsApp number aur details dalna](#7-apna-whatsapp-number-aur-details-dalna) ← **SAB SE ZAROORI**
8. [Products add / edit / delete karna](#8-products-add--edit--delete-karna)
9. [Product ki photo badalna](#9-product-ki-photo-badalna)
10. [Discount coupons banana](#10-discount-coupons-banana)
11. [Shipping charges set karna](#11-shipping-charges-set-karna)
12. [Website ka text badalna](#12-website-ka-text-badalna)

**Hissa 3 — Baad ka kaam**
13. [Google par website lana (SEO)](#13-google-par-website-lana-seo)
14. [Masail aur unka hal](#14-masail-aur-unka-hal)
15. [Files ki list — kaunsi file kis liye hai](#15-files-ki-list--kaunsi-file-kis-liye-hai)
16. [Final checklist](#16-final-checklist)

---

# HISSA 1 — WEBSITE LIVE KARNA

## 1. Aap ko kya kya chahiye

| Cheez | Kitna kharcha | Kahan se |
|---|---|---|
| Domain (`eleventhstitch.com`) | Rs. 3,000 – 4,500 / saal | Namecheap, GoDaddy, ya Pakistani reseller |
| Hosting (shared, cheapest plan) | Rs. 3,000 – 8,000 / saal | Hostinger, Namecheap, NexusHost, HostBreak |
| SSL certificate | **Rs. 0 — free** | Hosting ke andar Let's Encrypt |
| **Total** | **Rs. 6,000 – 12,000 / saal** | |

### Bohat aham baat

Ye website **static** hai — iska matlab ye hai ke isko koi database ya PHP ki zaroorat
nahi. Ye sirf HTML, CSS aur JavaScript files hain. Faida:

- **Sab se sasti hosting bhi chalegi.** Rs. 250/mahina wala plan kaafi hai.
- Website **bohat tez** khulegi.
- Hack hone ka khatra na ke barabar hai (koi login, koi database nahi).
- Koi monthly server bill nahi, koi maintenance nahi.

### Orders kaise aayenge?

Customer cart mein products dalta hai → checkout form bharta hai (naam, phone, address)
→ **"Confirm Order" dabata hai** → uska WhatsApp khul jata hai jis mein poora order
already likha hua hota hai → wo bas Send dabata hai → **order aap ke WhatsApp par aa
jata hai.**

Payment ke 3 tareeqe website par diye gaye hain:
1. **Cash on Delivery** — customer courier ko cash deta hai
2. **Bank / JazzCash / Easypaisa transfer** — aap ke account details checkout par khud
   dikhte hain, customer transfer kar ke screenshot bhej deta hai
3. **WhatsApp par baat kar ke tay karna** — bulk orders ke liye

**Card payment (Visa/Master) ke baare mein saaf baat:** static website par asli online
card gateway nahi chal sakta. Uske liye server-side code + merchant account chahiye
hota hai (bank se approval, monthly fees, documentation). Aap ne gateway maanga tha,
to main saaf bata deta hoon — aaj ke setup mein wo nahi hai, uski jagah upar wale 3
tareeqe hain jo Pakistan mein 95% online stores isi tarah chalate hain. Baad mein agar
sale barh jaye to gateway add karaya ja sakta hai; code aisa likha gaya hai ke us waqt
poori website dobara banane ki zaroorat nahi paregi.

---

## 2. Domain kharidna

### Naam ke options (jo pehle available ho, wo le lein)

```
eleventhstitch.com        ← sab se behtar
eleventhstitch.pk
eleventhstitch.com.pk
11thstitch.com
eleventhstitchpk.com
```

`.com` sab se behtar hai — log yaad rakhte hain aur Google bhi trust karta hai.
`.pk` sirf Pakistan ke customers ke liye theek hai lekin thora mehnga aur documentation
maangta hai.

### Kahan se kharidein

| Site | Qeemat (approx) | Note |
|---|---|---|
| **Namecheap.com** | $10–12 / saal | Free WHOIS privacy, aasan panel — **recommended** |
| Hostinger.com | $10 / saal | Hosting ke saath first year free milta hai |
| GoDaddy.com | $12–20 | Pehla saal sasta, renewal mehnga |
| PKNIC.pk | Rs. 3,500 | Sirf `.pk` ke liye |

### Kharidne ka tareeqa

1. Namecheap.com kholein → search box mein `eleventhstitch.com` likhein
2. Agar "available" likha aaye to **Add to Cart** dabayein
3. Checkout par jayein
4. **WHOIS privacy zaroor ON rakhein** (Namecheap par free hai) — warna aap ka naam,
   ghar ka address aur phone number internet par public ho jata hai aur spam calls
   shuru ho jati hain
5. Card ya PayPal se payment karein
6. Email par jo confirmation aaye, use **sambhal kar rakhein**

**⚠️ Ek bohat aham baat:** domain kharidne ke baad Namecheap aap ko ek verification
email bhejta hai. **48 ghante ke andar us email ka link zaroor click karein**, warna
ICANN aap ka domain temporarily band kar deta hai.

**Auto-renew ON rakhein.** Agar domain expire ho gaya to koi doosra banda use kharid
sakta hai aur aap ka business naam haath se nikal jaye ga.

---

## 3. Hosting kharidna

### Kya lena hai

**Shared hosting ka sab se sasta plan.** Bas itna dekh lein ke ye 3 cheezein hon:

- ✅ **cPanel** (ya kisi bhi tarah ka File Manager)
- ✅ **Free SSL** / Let's Encrypt
- ✅ Kam az kam **1 GB** space (hamari website sirf **3.6 MB** hai, to 1 GB bohat zyada hai)

VPS, cloud, ya "WordPress hosting" **mat** lein — faida nahi, paisa zyada.

### Recommended options

| Company | Plan | Qeemat | Faida / Nuqsan |
|---|---|---|---|
| **Hostinger** | Premium Web Hosting | ~Rs. 350/mah | Free domain 1st year, tez, aasan panel — **best value** |
| **Namecheap** | Stellar | ~$1.98/mah | Domain + hosting aik jagah, reliable |
| **NexusHost.pk** | Starter | ~Rs. 300/mah | Pakistani — local bank/JazzCash se payment ho jati hai |
| **HostBreak.com** | Economy | ~Rs. 400/mah | Pakistani, Urdu support, phone par baat ho jati hai |
| **Cloudflare Pages** | Free | **Rs. 0** | Bilkul muft, magar cPanel nahi — thora technical hai |

**Meri raye:** agar aap ko technical cheezein pasand nahi to **Hostinger** ka
sab se sasta plan lein aur domain bhi wahin se le lein — dono aik hi jagah honge,
DNS ka jhanjhat khatam, aur pehle saal domain free mil jata hai.

Agar Rs. 0 kharcha karna hai to **Cloudflare Pages** par ye website muft hamesha ke
liye chal sakti hai (sirf domain ka paisa lagega). Us ka tareeqa neeche step 4 mein
"Tareeqa C" ke naam se diya hai.

### Kharidne ke baad

Hosting company aap ko ek **welcome email** bhejti hai. Us mein ye cheezein hoti hain —
**is email ko delete mat karein:**

```
cPanel URL      : https://aapkidomain.com:2083   (ya server ka IP)
cPanel username : u123456789
cPanel password : ••••••••
FTP host        : ftp.aapkidomain.com
Nameservers     : ns1.hostinger.com
                  ns2.hostinger.com
```

Ye **nameservers** wali line aage step 5 mein kaam aaye gi. Isko note kar lein.

---

## 4. Files upload karna

Website ka poora folder aap ke paas hai: **`eleventh-stitch`**. Is ke andar
`index.html`, `assets` folder waghera sab kuch hai.

Teen tareeqe hain. **Tareeqa A sab se aasan hai.**

---

### Tareeqa A — cPanel File Manager (sab se aasan, recommended)

1. `eleventh-stitch` folder ki **ZIP** banayein
   - Windows: folder par right-click → **Send to → Compressed (zipped) folder**
   - Mac: right-click → **Compress**
   - **Zaroori:** ZIP ke andar seedha `index.html` hona chahiye. Agar ZIP kholne par
     ek aur folder aata hai jis ke andar `index.html` hai, to andar wale folder ki
     files select kar ke ZIP banayein.

2. cPanel mein login karein (welcome email wala URL aur password)

3. **File Manager** par click karein

4. Left side se **`public_html`** folder kholein
   - Kuch hosting par ye `www` ya `htdocs` kehlata hai — matlab wohi hai

5. **`public_html` ke andar jo purani files hain unhein delete kar dein** — aksar
   `default.html`, `index.html` ya `cgi-bin` hota hai. Ye hosting company ki "Coming
   Soon" page hoti hai, iski zaroorat nahi.

6. Upar **Upload** button dabayein → apni ZIP file select karein → upload hone ka
   intezar karein (3.6 MB hai, 30 second lagenge)

7. File Manager par wapas jayein, ZIP file par **right-click → Extract**

8. Ab dekhein ke `public_html` ke andar seedha ye cheezein nazar aa rahi hain:
   ```
   public_html/
     ├── index.html      ← ye seedha yahan hona chahiye
     ├── shop.html
     ├── product.html
     ├── cart.html
     ├── ... baqi html files
     ├── assets/
     ├── robots.txt
     └── sitemap.xml
   ```
   Agar `public_html/eleventh-stitch/index.html` ban gaya hai to **galat hai** —
   andar wali saari files ko select kar ke `public_html` mein move (cut-paste) karein.

9. ZIP file ko delete kar dein (kaam khatam, khali jagah kha rahi hai)

10. Browser mein apni domain kholein — website chal rahi hogi 🎉

---

### Tareeqa B — FileZilla (FTP se)

Agar cPanel na ho ya baar baar files badalni hon:

1. **FileZilla** download karein — [filezilla-project.org](https://filezilla-project.org) (free)
2. Kholein aur upar wale khanon mein welcome email ki details dalein:
   - Host: `ftp.aapkidomain.com`
   - Username / Password: jo email mein diya hai
   - Port: `21`
3. **Quickconnect** dabayein
4. Right side (server) par `public_html` kholein
5. Left side (aap ka computer) par `eleventh-stitch` folder kholein
6. Left se **saari files select karein** (Ctrl+A) → right side par **drag** kar dein
7. Neeche transfer complete hone ka intezar karein

---

### Tareeqa C — Cloudflare Pages (bilkul free, hosting ki zaroorat nahi)

Agar hosting ka paisa bachana hai. Sirf domain kharidna paregi.

1. [dash.cloudflare.com](https://dash.cloudflare.com) par free account banayein
2. **Workers & Pages → Create → Pages → Upload assets** par jayein
3. Project ka naam likhein: `eleventh-stitch`
4. `eleventh-stitch` folder ko **drag & drop** kar dein
5. **Deploy** dabayein — 20 second mein live!
6. Aap ko ek link milega: `eleventh-stitch.pages.dev` — abhi se chal raha hai
7. Apni domain lagane ke liye: **Custom domains → Set up a domain** → apni domain
   likhein → Cloudflare khud DNS set kar dega

**Faida:** muft, dunya ka sab se tez CDN, SSL automatic, unlimited traffic.
**Nuqsan:** cPanel nahi milta; files badalne ke liye har dafa dobara upload karna
parta hai (magar wo bhi drag-drop hi hai).

---

## 5. Domain ko hosting se jorna (DNS)

**Ye step sirf tab karna hai jab domain aur hosting alag alag company se li hon.**
Agar dono aik hi company (jaise Hostinger) se li hain to ye khud ho jata hai — seedha
step 6 par chale jayein.

### Tareeqa

1. **Hosting** ke welcome email se nameservers copy karein, jaise:
   ```
   ns1.hostinger.com
   ns2.hostinger.com
   ```

2. **Domain** wali company (Namecheap) mein login karein

3. **Domain List → Manage** (apni domain ke saamne)

4. **Nameservers** ka section dhoondein → dropdown se **Custom DNS** chunein

5. Dono nameservers paste karein → **✓ (tick)** dabayein save karne ke liye

6. **Intezar karein.** Ye "DNS propagation" kehlata hai:
   - Aam tor par: **30 minute se 2 ghante**
   - Kabhi kabhi: **24 ghante tak**
   - Is dauran website kabhi khulti kabhi nahi khulti — ye **normal hai**, ghabrayein nahi

7. Check karne ke liye [dnschecker.org](https://dnschecker.org) par apni domain daal
   kar dekhein — dunya bhar ke servers par green tick aa jayein to kaam ho gaya

### www ke saath aur baghair — dono chalne chahiye

`eleventhstitch.com` aur `www.eleventhstitch.com` — dono par website khulni chahiye.
cPanel mein ye by default set hota hai. Agar `www` par na khule to cPanel →
**Domains → Create a new domain** mein `www.aapkidomain.com` add kar dein, ya support
ko WhatsApp/ticket kar dein — 5 minute ka kaam hai.

---

## 6. SSL lagana — https ka green lock

Ye **bilkul free** hai aur **zaroori** hai. SSL ke baghair Chrome aap ki website par
customers ko **"Not Secure"** ki warning dikhata hai — log darr ke bhaag jate hain aur
Google ranking bhi girti hai.

### Steps

1. cPanel mein login karein
2. **SSL/TLS Status** dhoondein (Security section mein hota hai)
3. Apni domain ke saamne checkbox tick karein
4. **Run AutoSSL** dabayein
5. 5–15 minute intezar karein
6. Browser mein `https://aapkidomain.com` kholein — address bar mein **🔒 lock** aa
   jaye ga

Hostinger par ye khud lag jata hai. Cloudflare Pages par bhi automatic hai.

### http ko https par bhejna (force redirect)

Taake koi `http://` par aaye to khud `https://` par chala jaye:

- **Aasan tareeqa:** cPanel → **Domains** → apni domain ke saamne **"Force HTTPS
  Redirect"** ka switch ON kar dein. Bas.

- **Agar switch na mile:** cPanel File Manager mein `public_html` ke andar
  `.htaccess` naam ki file banayein (File Manager → **+ File**) aur us mein ye paste
  karein:

  ```apache
  RewriteEngine On
  RewriteCond %{HTTPS} off
  RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]

  # 404 page
  ErrorDocument 404 /404.html

  # Browser caching — website tez khulegi
  <IfModule mod_expires.c>
    ExpiresActive On
    ExpiresByType image/jpeg "access plus 1 year"
    ExpiresByType image/svg+xml "access plus 1 year"
    ExpiresByType text/css "access plus 1 month"
    ExpiresByType application/javascript "access plus 1 month"
  </IfModule>

  # Files ko compress karna
  <IfModule mod_deflate.c>
    AddOutputFilterByType DEFLATE text/html text/css application/javascript image/svg+xml
  </IfModule>
  ```

  Ye file 404 page aur speed dono theek kar deti hai. Cloudflare Pages par iski
  zaroorat nahi (wahan sab automatic hai).

---

# HISSA 2 — WEBSITE APNI BANANA

## 7. Apna WhatsApp number aur details dalna

> ### ⚠️ YE SAB SE ZAROORI STEP HAI
> Abhi website par **naqli (dummy) number aur bank account** hai. Jab tak aap ise nahi
> badlenge, **customer ke orders aap ko nahi milenge** — kisi aur ke number par jayenge.
> Website live karne se pehle ye step kar lein.

### Kaunsi file badalni hai

**Sirf ek file: `assets/js/products.js`**

Ye poori website ka dimagh hai. Products, prices, WhatsApp number, bank details,
coupons, shipping — sab isi mein hai. **Baqi kisi file ko chhune ki zaroorat nahi.**

### Kholne ka tareeqa

- **cPanel se:** File Manager → `public_html/assets/js/` → `products.js` par
  right-click → **Edit** → seedha browser mein edit ho jaye gi → **Save Changes**
- **Computer par:** file par right-click → **Open with → Notepad** (Windows) ya
  **TextEdit** (Mac). Behtar hai **Notepad++** ya **VS Code** (dono free) use karein,
  unme rang alag alag dikhte hain aur ghalti pakarni aasan hoti hai
- ⚠️ **MS Word mein hargiz na kholein** — wo file kharab kar deta hai

### Kya badalna hai — file ki shuru ki lines

File kholte hi upar `STORE` naam ka hissa milega. Ye lines badalni hain:

```js
const STORE = {
  name: "Eleventh Stitch",
  tagline: "Sleep, Stitched Right",

  // WhatsApp number: country code ke saath, koi +, space ya dash nahi
  // Pakistan example: 0300 1234567  ->  923001234567
  whatsapp: "923001234567",        // ← ★ APNA NUMBER YAHAN

  phone: "+92 300 123 4567",       // ← apna number (dikhane ke liye)
  email: "orders@eleventhstitch.com",  // ← apni email
  address: "Shop 11, Textile Plaza, Main Boulevard, Lahore, Pakistan",  // ← apna address
  hours: "Mon – Sat, 10:00 am – 9:00 pm",   // ← apne timings

  instagram: "https://instagram.com/",      // ← apna page ka link
  facebook: "https://facebook.com/",
  tiktok: "https://tiktok.com/",
```

### WhatsApp number ka format — dhyan se

Ye sab se zyada ghalti hone wali jagah hai. Number **country code ke saath, baghair
`+`, baghair space, baghair dash** likhna hai:

| Aap ka number | File mein kya likhein |
|---|---|
| 0300 1234567 | `"923001234567"` ✅ |
| 0321-4567890 | `"923214567890"` ✅ |
| +92 333 9876543 | `"923339876543"` ✅ |

**Ye ghaltiyan mat karein:**

| Ghalat | Kyun ghalat |
|---|---|
| `"03001234567"` ❌ | Country code (92) nahi hai |
| `"+923001234567"` ❌ | `+` nahi hona chahiye |
| `"92 300 1234567"` ❌ | Space nahi hona chahiye |
| `"923001234567` ❌ | Aakhir ka `"` gayab hai — website band ho jaye gi |

**Formula:** `0` hatayein → shuru mein `92` lagayein → saare space/dash hatayein.

### Bank aur wallet details

Thora neeche `bank` ka hissa hai. Ye checkout page par customer ko dikhta hai jab wo
"Bank transfer" chunta hai:

```js
  bank: {
    bankName: "Meezan Bank",                    // ← apna bank
    title: "Eleventh Stitch",                   // ← account holder ka naam
    account: "0123 4567 8901 2345",             // ← apna account number
    iban: "PK00MEZN0001234567890123",           // ← apna IBAN
    jazzcash: "0300 123 4567",                  // ← JazzCash number
    easypaisa: "0300 123 4567",                 // ← Easypaisa number
  },
```

⚠️ **In numbers ko teen dafa check karein.** Ghalat account number ka matlab hai
customer ka paisa kisi aur ke paas chala gaya.

Agar aap ke paas JazzCash ya Easypaisa nahi hai to us line mein `""` (khali) kar dein —
wo option khud chhup jaye ga:
```js
    jazzcash: "",
    easypaisa: "",
```

### Save karne ke baad — bohat aham

File save karne ke baad website par **turant tabdeeli nazar nahi aaye gi**, kyunke
browser purani copy yaad rakhta hai (cache). Isko theek karne ke liye:

**Har HTML file mein `?v=1` ko `?v=2` kar dein.** Har page ki neeche wali 2 lines aur
upar wali 1 line mein ye hota hai:

```html
<link rel="stylesheet" href="assets/css/style.css?v=1">
<script src="assets/js/products.js?v=1"></script>
<script src="assets/js/app.js?v=1"></script>
```

Inhe `?v=2` kar dein. Agli dafa `?v=3`, phir `?v=4`. Isse customers ko naya version
foran mil jata hai.

**Jaldi ka tareeqa (test karne ke liye):** browser mein **Ctrl + Shift + R**
(Mac: **Cmd + Shift + R**) dabayein — ye cache ignore kar deta hai.

### Test kaise karein ke number sahi laga

1. Website kholein
2. Koi product **cart mein daalein**
3. **Checkout** par jayein, form bharein (apna hi naam/number daal dein)
4. **Confirm Order** dabayein
5. WhatsApp khulna chahiye, **aap ke apne number par**, poora order likha hua
6. Send kar dein — agar message aa gaya to **sab kaam kar raha hai** ✅

---

## 8. Products add / edit / delete karna

Sab kuch usi file mein hai: **`assets/js/products.js`**, `PRODUCTS` ke hisse mein.
Abhi **27 products** mojood hain.

### Product ka structure — har hisse ka matlab

```js
  {
    id: "orthopedic-support-mattress",   // unique naam, URL mein aata hai
    name: "Orthopedic Support Mattress", // jo customer ko dikhega
    cat: "mattresses",                   // category (list neeche hai)
    price: 42500,                        // bechne ki qeemat — sirf number!
    was: 52000,                          // purani qeemat (0 = discount na dikhaye)
    badge: "sale",                       // "sale" | "new" | ""
    stock: true,                         // true = mojood, false = Sold Out
    rating: 4.8,                         // sitare (1 se 5)
    reviews: 214,                        // kitne logon ne review kiya
    img: "assets/products/mattress-orthopedic.jpg",   // photo ka path
    short: "High-density orthopedic core with a quilted knit cover…",
    options: {                           // size / variant
      label: "Size",
      list: [
        { name: "Single", sub: "36 × 75 in", add: 0 },      // add = extra paisay
        { name: "Double", sub: "48 × 75 in", add: 9500 },   // 42500 + 9500 = 52000
        { name: "Queen",  sub: "60 × 78 in", add: 17000 },
      ],
    },
    features: [                          // bullet points
      "High-density rebonded orthopedic foam core",
      "Firm support that keeps the spine naturally aligned",
    ],
    specs: {                             // table mein dikhta hai
      "Thickness": "8 inches",
      "Firmness": "Firm (8/10)",
      "Warranty": "10 years",
    },
  },
```

### Category ke naam (`cat` mein sirf ye 5 chal sakte hain)

| Likhein | Website par dikhega |
|---|---|
| `mattresses` | Mattresses |
| `pillows` | Pillows |
| `bedding` | Bedding |
| `protectors` | Protectors & Toppers |
| `decor` | Cushions & Decor |

⚠️ Bilkul aise hi likhein — chhote harf, koi space nahi. `Mattresses` ya `mattress`
likhne se product kisi category mein nazar nahi aaye ga.

---

### Kaam A — Sirf price badalna (sab se aam kaam)

Product dhoondein, `price` wala number badal dein:

```js
    price: 42500,     ← isko  price: 45000,  kar dein
```

**Bas.** Website ke har page par nayi price khud aa jaye gi — home page, shop page,
product page, cart, checkout, WhatsApp order — sab jagah.

⚠️ **Number mein comma ya `Rs.` na likhein:**
- ✅ `price: 45000,`
- ❌ `price: 45,000,` — website band ho jaye gi
- ❌ `price: "Rs. 45000",` — ghalat

---

### Kaam B — Sale lagana

```js
    price: 38000,      // nayi (kam) qeemat
    was: 52000,        // purani qeemat
    badge: "sale",     // laal "sale" ka tag
```

Website khud hisab laga kar **"27% OFF"** ka tag dikha degi. Sale khatam karne ke liye:

```js
    was: 0,
    badge: "",
```

---

### Kaam C — Out of stock karna

```js
    stock: false,
```

Product par **"Sold Out"** likha aa jaye ga aur Add to Cart ka button band ho jaye ga.
Product delete karne se behtar hai — link zinda rehta hai aur Google ranking nahi girti.

---

### Kaam D — Naya product add karna

1. Koi milta-julta purana product **poora copy** karein — `{` se le kar `},` tak
2. Usi ke neeche **paste** karein
3. Ab details badlein:
   - `id` — **naya aur unique** hona chahiye. Chhote harf, space ki jagah dash:
     `"cotton-bed-sheet-set"` ✅ / `"Cotton Bed Sheet"` ❌
   - `name`, `price`, `cat`, `short` — apne hisab se
   - `img` — photo ka path (agla section dekhein)
4. Save karein → shop page refresh karein → naya product aa gaya

**Product kaha dikhega?** Shop page par, apni category mein, sitemap mein — sab
khud-b-khud. Kuch aur karne ki zaroorat nahi.

---

### Kaam E — Product delete karna

Us product ka poora block — shuru ke `{` se le kar aakhir ke `},` tak — mita dein.

⚠️ Aakhir ka **comma `,` bhi** mitana zaroori hai, warna website band ho jaye gi.

**Behtar mashwara:** delete karne ki bajaye `stock: false` kar dein (Kaam C). Jo log
purana link share kar chuke hain, un ka link kaam karta rahega.

---

### 🔴 Comma aur quote ke 5 sunehri usool

JavaScript mein ek chhoti si ghalti poori website band kar deti hai. Ye 5 baatein yaad
rakhein:

1. **Har line ke aakhir mein comma** — `price: 42500,`
2. **Text ke dono taraf quotes** — `name: "Pillow",`
3. **Number par quotes NAHI** — `price: 2500,` (na ke `"2500"`)
4. **`true` / `false` par quotes NAHI** — `stock: true,`
5. **Har `{` ka ek `}` hona chahiye**

**Ghalti ki nishani:** website khali safed page dikhaye, ya products gayab ho jayein.

**Ghalti pakarne ka tareeqa:**
- **F12** dabayein → **Console** tab kholein → laal rang ki line mein likha hoga
  `products.js:127` — matlab line 127 par ghalti hai, wahan dekhein
- Ya [jsonlint.com](https://jsonlint.com) jaisi site par check karein

**Sab se zaroori aadat:** ⭐ **koi bhi tabdeeli karne se pehle `products.js` ki ek
copy bacha lein** — naam de dein `products-backup.js`. Kuch bigar jaye to purani file
wapas daal dein, 10 second mein sab theek.

---

## 9. Product ki photo badalna

Website par abhi **27 product photos** aur **8 scene photos** lagi hui hain (sab
optimize ki gayi hain — poori website sirf 3.6 MB hai).

Ye photos AI se banayi gayi hain. Ye chalti rahengi, magar **apne asli products ki
photos lagana bohat behtar hai** — customer ka bharosa barhta hai aur return kam aate
hain.

### Photo kaisi honi chahiye

| Cheez | Behtareen |
|---|---|
| Shape | **Square (chokor)** — barabar lambai-chorai |
| Size | **900 × 900 pixels** |
| File type | **JPG** (PNG bara hota hai, bilawajah) |
| Weight | **100 KB se kam** — zaroori! |
| Background | **Safed ya halka** — saaf suthra |
| Roshni | **Khidki ki natural light** — flash na chalayein |

### Badalne ka tareeqa (aasan)

1. Nayi photo ka naam **bilkul wohi rakhein jo purani ka hai** — jaise
   `mattress-orthopedic.jpg`
2. cPanel File Manager → `public_html/assets/products/` kholein
3. **Upload** dabayein → purani file par **Overwrite** confirm karein
4. Website par **Ctrl + Shift + R** — nayi photo aa gayi

**Faida:** `products.js` mein kuch badalne ki zaroorat nahi.

### Naya naam rakhna ho to

1. Photo `assets/products/` mein upload karein, jaise `mera-naya-pillow.jpg`
2. `products.js` mein us product ki `img` line badlein:
   ```js
   img: "assets/products/mera-naya-pillow.jpg",
   ```
3. ⚠️ **Naam mein space na rakhein** — `mera pillow.jpg` ❌ / `mera-pillow.jpg` ✅
   Aur chhote harf istemal karein (server bara-chhota farq karta hai).

### Photo halki (compress) karne ka tareeqa

Mobile se li hui photo 3–5 MB hoti hai. Aisi photo lagane se **website bohat slow ho
jaye gi** aur log chale jayenge. Pehle compress karein:

1. **[squoosh.app](https://squoosh.app)** kholein (Google ka free tool, browser mein
   chalta hai)
2. Photo drag kar dein
3. Right side se **MozJPEG** chunein, quality **80** rakhein
4. **Resize** ka tick lagayein → Width **900**
5. Neeche se **Download** — file 3 MB se ~80 KB ho jaye gi

Aur options: [tinypng.com](https://tinypng.com) (aur bhi aasan) ya
[iloveimg.com](https://iloveimg.com) (aik saath 20 photos).

### Mobile se acchi photo lene ke 6 tips

1. **Khidki ke paas** shoot karein, dopahar ki light mein — **flash bilkul band**
2. **Safed chaadar** ya deewar background mein lagayein
3. Phone ko **seedha (level)** rakhein, tirha nahi
4. Product ka **poora frame** bharein — bohat door se na khichein
5. **Detail ki alag photo** lein — silai, zip, label, fabric ka close-up
6. **Saare products ki photo aik hi jagah aik hi light mein** lein — website
   professional lagti hai jab sab photos aik jaisi hon

### Baqi photos jo badal sakte hain

`assets/img/` folder mein:

| File | Kahan dikhti hai |
|---|---|
| `hero-bedroom.jpg` | Home page ki sab se upar wali bari photo |
| `hero-detail.jpg` | Home page par silai ka close-up |
| `about-workshop.jpg` | About page ki photo |
| `cat-mattress.jpg` | "Mattresses" category card |
| `cat-pillow.jpg` | "Pillows" category card |
| `cat-bedding.jpg` | "Bedding" category card |
| `cat-protector.jpg` | "Protectors & Toppers" card |
| `cat-decor.jpg` | "Cushions & Decor" card |

Hero photos **1600 pixels** chaurai ki rakhein (ye bari dikhti hain), category photos
900 × 900.

### Favicon (browser tab ka chhota logo)

`assets/img/favicon.svg` — abhi is mein "11" likha hai. Apna logo lagana ho to
[favicon.io](https://favicon.io) par bana kar `favicon.svg` ke naam se replace kar dein.

---

## 10. Discount coupons banana

`products.js` mein `coupons` ka hissa:

```js
  coupons: {
    STITCH10: { off: 10, min: 5000 },     // 10% off, minimum Rs. 5,000 ka order
    SLEEP15:  { off: 15, min: 15000 },    // 15% off, minimum Rs. 15,000
    NEW5:     { off: 5,  min: 0 },        // 5% off, koi minimum nahi
  },
```

- `off` = kitne **percent** discount
- `min` = kam az kam kitne ka order hona chahiye (`0` = koi shart nahi)

### Naya coupon banana

Aik nayi line add kar dein:

```js
  coupons: {
    STITCH10: { off: 10, min: 5000 },
    SLEEP15:  { off: 15, min: 15000 },
    NEW5:     { off: 5,  min: 0 },
    EID20:    { off: 20, min: 20000 },     // ← naya: Eid sale
    RAMZAN10: { off: 10, min: 8000 },      // ← naya
  },
```

### Usool

- Code **BARE HARF** mein likhein: `EID20` ✅ / `eid20` ❌
- Code mein **space na ho**: `EID20` ✅ / `EID 20` ❌
- Customer chhote harf mein bhi likhe to chal jaye ga (website khud bara kar deti hai)
- Discount **shipping se pehle** subtotal par lagta hai
- **Aik waqt mein aik hi coupon** chalta hai — do coupon jama nahi hote
- Agar order `min` se kam hai to customer ko khud message dikhta hai:
  *"This code needs a minimum order of Rs. X"*

### Coupon khatam karna

Us line ko mita dein (aakhir ka comma bhi). Jo log purana code lagayenge, un ko
**"Invalid code"** ka message aaye ga.

### Coupon customer tak kaise pohnche

Ye code khud se kisi ko nazar nahi aate — aap ko batana parta hai:
- Instagram / Facebook post mein
- WhatsApp status par
- Website ke sab se upar wali patti (announcement bar) mein — us ka text badalne ke
  liye section 12 dekhein

---

## 11. Shipping charges set karna

`products.js` mein:

```js
  currency: "Rs.",
  freeShipOver: 10000,      // is amount se upar shipping free
  shipFlat: 350,            // normal delivery charges
  codFee: 0,                // cash on delivery extra fee (0 = free)
```

| Line | Matlab | Misaal |
|---|---|---|
| `freeShipOver` | Is amount se zyada order par delivery **free** | `10000` = Rs. 10,000+ par free |
| `shipFlat` | Uske neeche kitne charges | `350` = Rs. 350 |
| `codFee` | COD par extra fee | `0` = free |

### Aam tabdeeliyan

**Delivery hamesha free karni ho:**
```js
  freeShipOver: 0,
  shipFlat: 0,
```

**Free delivery ki had barhani ho (order value barhane ke liye):**
```js
  freeShipOver: 15000,
```

**COD par handling fee lagani ho:**
```js
  codFee: 200,
```

### Free shipping ka nudge — ye khud kaam karta hai

Cart page par customer ko khud dikhta hai:

> *"Add Rs. 2,400 more for free delivery"*

Aur ek progress bar bharta hua nazar aata hai. Ye **order ki value barhane ka bohat
purwasar tareeqa** hai — log free delivery ke liye ek cheez zyada daal dete hain.
`freeShipOver` badalne par ye message khud adjust ho jata hai.

### Delivery ke din aur zone

Ye `shipping.html` page mein table ki shakl mein likhe hain (Lahore 1–2 din, Karachi
2–4 din waghera). Apne courier ke hisab se badalna ho to:

- cPanel File Manager → `shipping.html` → **Edit**
- Table mein sheher aur din badal dein
- Aisi hi table `faq.html` mein bhi mention hai — dono jagah aik jaisa rakhein

---

## 12. Website ka text badalna

Har page ka text uski HTML file mein hai. cPanel File Manager mein file par
**right-click → Edit** kar ke seedha badla ja sakta hai.

⚠️ **Usool:** sirf `>` aur `<` ke **darmiyan** wala text badlein. Tags (`<h1>`, `<p>`,
`class="..."`) ko na chhuein.

**Misaal:**
```html
<h1>Talk to a real person</h1>
      ↑ sirf ye hissa badlein
```

### Kaunsa text kis file mein hai

| Page | File | Us mein kya hai |
|---|---|---|
| Home | `index.html` | Hero heading, "27 Products" wale stats, brand story |
| Shop | `shop.html` | Page ka title, custom-size ki patti |
| About | `about.html` | Brand ki kahani, 4 usool, numbers |
| FAQ | `faq.html` | *(Sawal-jawab `products.js` mein hain — neeche dekhein)* |
| Contact | `contact.html` | Bulk order aur custom size ke box |
| Shipping | `shipping.html` | Delivery table, charges, returns, warranty |
| Privacy | `privacy.html` | Privacy policy aur terms |
| 404 | `404.html` | "Page not found" ka message |

### Sab se upar wali patti (announcement bar)

Ye har page par sab se upar dikhti hai. `assets/js/app.js` **line 163** par hai:

```js
'<div class="announce">Free delivery on orders over <b>' + money(STORE.freeShipOver) +
'</b> &nbsp;·&nbsp; Cash on delivery all over Pakistan</div>' +
```

Sale ka elaan karna ho to aise badal dein:

```js
'<div class="announce">EID SALE — 20% OFF, code <b>EID20</b>' +
'&nbsp;·&nbsp; Free delivery over Rs. 10,000</div>' +
```

⚠️ Quotes `'` aur aakhir ka `+` sahi jagah rehne dein.

### FAQ ke sawal-jawab

Ye `products.js` ke **aakhir** mein `FAQS` naam ke hisse mein hain (8 sawal):

```js
const FAQS = [
  {
    q: "Delivery mein kitne din lagte hain?",
    a: "Lahore ke andar 1–2 working days…",
  },
  // ... baqi
];
```

Naya sawal add karna:
```js
  {
    q: "Kya installment par mil sakta hai?",
    a: "Filhaal hum sirf full payment lete hain — cash on delivery ya bank transfer.",
  },
```
FAQ page par khud aa jaye ga.

### Customer reviews

`products.js` mein `REVIEWS` ka hissa (home page par dikhte hain):

```js
const REVIEWS = [
  { name: "Ayesha K.", city: "Lahore", rating: 5,
    text: "Mattress ki quality expectation se behtar thi…" },
];
```

Asli customers ke review milte rahein to yahan add karte jayein — **jhoote review na
lagayein**, log pakar lete hain aur bharosa khatam ho jata hai.

### Logo ka "11"

Header mein `11` likha aata hai (`app.js` line 167). Asli logo image lagani ho to
`<span class="logo__mark">11</span>` ki jagah:

```html
<img src="assets/img/logo.png" alt="Eleventh Stitch" style="height:40px">
```

Aur `assets/img/logo.png` upload kar dein.

---

# HISSA 3 — BAAD KA KAAM

## 13. Google par website lana (SEO)

Technical SEO **pehle se ho chuka hai**: har page ka title aur description, Open Graph
tags (WhatsApp/Facebook par share karne par photo dikhti hai), `robots.txt`,
`sitemap.xml` (34 links), cart/checkout par `noindex`, mobile-friendly design, aur tez
loading speed.

Aap ko sirf 3 kaam karne hain:

### Kaam 1 — sitemap mein apni domain likhein ⚠️

`sitemap.xml` mein abhi `eleventhstitch.com` likha hai. Agar aap ki domain koi aur hai
to badalna **zaroori** hai warna Google confuse ho jaye ga.

- cPanel File Manager → `sitemap.xml` → **Edit**
- **Ctrl + H** (Find & Replace) → `eleventhstitch.com` ko apni domain se replace karein
- Sab 34 lines mein badal jaye ga → **Save**

Yehi `robots.txt` mein bhi karein (aakhir wali `Sitemap:` line).

### Kaam 2 — Google Search Console

1. [search.google.com/search-console](https://search.google.com/search-console) par
   jayein (Gmail se login)
2. **Add Property → URL prefix** → apni domain likhein: `https://aapkidomain.com`
3. Verify karne ke liye **HTML file** ka tareeqa chunein → file download karein →
   cPanel se `public_html` mein upload kar dein → **Verify** dabayein
4. Left menu se **Sitemaps** → likhein `sitemap.xml` → **Submit**
5. **Bas.** Google 3–7 din mein aap ki website index karna shuru kar deta hai

### Kaam 3 — Google Business Profile (Pakistan mein sab se zyada faida)

Ye **muft** hai aur local customers ke liye Search Console se bhi zyada kaam ka:

1. [business.google.com](https://business.google.com) par jayein
2. Business add karein: naam **Eleventh Stitch**, category **Mattress Store** ya
   **Bedding Store**
3. Apna shop ka address, phone number, timings daalein
4. **Website mein apni domain daalein**
5. Google post ya phone call se verify karega
6. Products ki photos upload karein

Iske baad jab koi Lahore mein "mattress shop near me" search karega, aap Google Maps
par nazar aayenge. **Ye asli customers late hai.**

### Rank barhane ke aam mashwarey

- **Product ke `short` mein wo lafz likhein jo log search karte hain** — "orthopedic
  mattress for back pain Lahore", "waterproof mattress protector price in Pakistan"
- **Naye products add karte rahein** — Google active websites ko pasand karta hai
- **Instagram / Facebook par website ka link** har post mein dein
- **Asli reviews** lein — Google Business par review maangna order pack karte waqt
  parchi mein likh dein
- **Sabar karein** — nayi website ko Google par aana **2–3 mahine** lagte hain. Ye
  normal hai.

### Analytics (kitne log aa rahe hain — optional)

Dekhna ho ke roz kitne log website par aate hain:

1. [analytics.google.com](https://analytics.google.com) par free account banayein
2. Aap ko ek code milega jo `<!-- Google tag -->` se shuru hota hai
3. Us code ko **har HTML file** mein `</head>` se **thora pehle** paste kar dein

**Ya iss se bhi aasan:** [cloudflare.com](https://cloudflare.com) ka free plan lein —
Web Analytics khud mil jata hai, koi code lagane ki zaroorat nahi, aur website bhi tez
ho jati hai.

⚠️ Agar analytics lagayein to `privacy.html` mein cookies wale hisse ko update kar dein
— abhi us mein likha hai ke hum analytics use nahi karte.

---

## 14. Masail aur unka hal

### Website khulti hi nahi

| Wajah | Hal |
|---|---|
| DNS abhi phaila nahi | 2–24 ghante intezar karein. [dnschecker.org](https://dnschecker.org) par check karein |
| Nameservers ghalat | Step 5 dobara dekhein |
| Files ghalat jagah hain | `index.html` **seedha `public_html` ke andar** hona chahiye, kisi folder ke andar nahi |

### Khali safed page aata hai

**99% chance:** `products.js` mein comma ya quote ki ghalti hai.

1. **F12** dabayein → **Console** tab
2. Laal line mein likha hoga jaise `Uncaught SyntaxError ... products.js:342`
3. Us line number par jayein — wahan comma ya quote missing hoga
4. Nahi samajh aaye to **`products-backup.js`** wapas daal dein

**Isi liye backup rakhna zaroori hai.**

### Products nazar nahi aate

- `products.js` mein ghalti hai (upar wala step dekhein)
- Ya `cat` galat likha hai — sirf ye 5 chal sakte hain: `mattresses`, `pillows`,
  `bedding`, `protectors`, `decor`

### Photos nahi dikhti (toota hua icon aata hai)

| Wajah | Hal |
|---|---|
| `assets` folder upload nahi hua | Poora `assets` folder upload karein |
| Naam mein farq | Server **bara-chhota harf** ka farq karta hai: `Mattress.JPG` ≠ `mattress.jpg` |
| Naam mein space | `my photo.jpg` ❌ → `my-photo.jpg` ✅ |
| Path galat | `products.js` mein path aisa ho: `assets/products/naam.jpg` |

### Tabdeeli nazar hi nahi aa rahi (sab se aam masla!)

**Browser purani copy dikha raha hai (cache).**

- **Foran hal:** **Ctrl + Shift + R** (Mac: **Cmd + Shift + R**)
- **Customers ke liye hal:** har HTML file mein `?v=1` ko `?v=2` kar dein
- Cloudflare use kar rahe hain to dashboard se **Purge Cache** dabayein

### WhatsApp par order nahi aa raha

1. `products.js` mein `whatsapp:` wala number check karein
2. Format sahi hai? `923001234567` — **`92` ke saath, `+` aur space ke baghair**
3. Us number par WhatsApp **install aur active** hona chahiye
4. Business number ho to **WhatsApp Business** app install karein

### Chrome "Not Secure" dikha raha hai

SSL nahi laga. Section 6 dekhein — cPanel → SSL/TLS Status → **Run AutoSSL**.

### Mobile par website toot rahi hai

Website poori tarah mobile-friendly banayi gayi hai aur test bhi ki gayi hai. Agar
masla ho to:
1. `style.css` poora upload hua? File 60 KB se zyada honi chahiye
2. Cache clear karein (**Ctrl + Shift + R**)
3. Kisi HTML file mein aap ne kuch edit kar ke tag tor diya ho — us file ki backup
   wapas daal dein

### Ghalat page par 404 aata hai

`.htaccess` mein `ErrorDocument 404 /404.html` ki line add karein (section 6 mein poora
code diya hai).

### 🆘 Kuch bhi bigar jaye to

Aap ke paas **poora original folder** mojood hai. Kabhi bhi:
1. cPanel → `public_html` ki saari files delete karein
2. Original folder dobara upload karein
3. `products.js` mein apna WhatsApp number aur bank details dobara daalein

**5 minute mein website waisi hi ho jaye gi jaisi pehle din thi.** Isliye original
folder ko computer par aur Google Drive par — dono jagah **sambhal kar rakhein**.

---

## 15. Files ki list — kaunsi file kis liye hai

```
eleventh-stitch/
│
├── index.html          Home page
├── shop.html           Saare products + filters
├── product.html        Aik product ki detail (URL: product.html?id=...)
├── cart.html           Shopping cart
├── checkout.html       Order form
├── thankyou.html       Order ke baad ka page
├── about.html          Hamari kahani
├── faq.html            Sawal-jawab
├── contact.html        Contact + form
├── shipping.html       Delivery, returns, warranty
├── privacy.html        Privacy policy + terms
├── 404.html            Page not found
│
├── robots.txt          Google ke liye hidayaat
├── sitemap.xml         Saare pages ki list (34 links)
├── SETUP-GUIDE.md      ← ye guide
│
└── assets/
    ├── css/
    │   └── style.css       Poori website ka design (1,270 lines)
    ├── js/
    │   ├── products.js     ★★★ SIRF YE FILE EDIT KARNI HAI ★★★
    │   └── app.js          Website ka engine — cart, filters, header, footer
    ├── products/           27 product photos
    └── img/                8 scene photos + favicon
```

### Aasan lafzon mein

| File | Chhuein? | Kaam |
|---|---|---|
| **`assets/js/products.js`** | ✅ **HAAN** | Products, prices, WhatsApp number, bank, coupons, shipping, FAQ, reviews |
| `assets/products/` + `assets/img/` | ✅ Haan | Photos badalne ke liye |
| `*.html` | ⚠️ Ehtiyat se | Sirf text badalne ke liye |
| `sitemap.xml` + `robots.txt` | ⚠️ Aik dafa | Apni domain daalne ke liye |
| `assets/css/style.css` | ❌ **NAHI** | Design — chhune se toot sakta hai |
| `assets/js/app.js` | ❌ **NAHI** | Engine — chhune se cart band ho sakta hai |

### Website mein kya kya bana hua hai

**Products aur browsing**
- 27 products, 5 categories, har product ki apni detail page
- Size/variant options jo price khud badalte hain
- Live search (likhte hi results)
- Category, price aur sale ke filters
- Sort: featured / kam price / zyada price / rating / naam
- Related products
- Sitare, reviews ki ginti, sale ke tags, "Sold Out" ka tag

**Cart aur order**
- Cart jo browser band karne ke baad bhi yaad rehta hai
- Quantity barhana/ghatana, item hatana
- Coupon codes (minimum order ki shart ke saath)
- Free shipping ka progress bar
- Checkout form poori validation ke saath
- 3 payment options: COD / bank transfer / WhatsApp par baat
- Order ka reference number (`ES######`)
- WhatsApp par poora order khud likha hua chala jata hai

**Design aur technical**
- Mobile, tablet, laptop — sab par perfect
- Poori website sirf **3.6 MB** — bijli/net slow ho to bhi khul jati hai
- Har page ka SEO title aur description
- WhatsApp/Facebook par share karne par photo aur title dikhta hai
- Scroll par halke animations (jo log animation band rakhte hain unke liye khud band)
- **0 JavaScript errors** — poori website test ki gayi hai
- Koi database nahi, koi login nahi → hack hone ka khatra na ke barabar

### Har mahine 5 minute ka kaam

- ✅ Domain aur hosting ki expiry date dekh lein (auto-renew ON hai?)
- ✅ Website mobile par khol kar dekh lein
- ✅ Aik test order kar ke dekhein ke WhatsApp par aa raha hai
- ✅ Out-of-stock products ko `stock: false` kar dein
- ✅ Naye products add karein — Google ko pasand hai

---

## 16. Final checklist

Isko print kar lein ya phone mein save kar lein. Har cheez tick karte jayein.

### Live karne se pehle

- [ ] Domain kharid li aur verification email ka link click kiya
- [ ] Hosting kharid li, welcome email sambhal ke rakha
- [ ] **`products.js` mein apna WhatsApp number dala** ← sab se zaroori
- [ ] `products.js` mein apna phone, email, address, timings dale
- [ ] `products.js` mein apne bank / JazzCash / Easypaisa ke asli numbers dale
- [ ] Bank account number **teen dafa** check kiya
- [ ] Instagram / Facebook ke asli links dale
- [ ] Prices apne hisab se set kiye
- [ ] Jo products nahi bechte, unhe hataya ya `stock: false` kiya
- [ ] `sitemap.xml` aur `robots.txt` mein apni domain dali
- [ ] **`products.js` ka backup** computer par rakha

### Live karne ke baad — test karein

- [ ] `https://aapkidomain.com` khulti hai
- [ ] `https://www.aapkidomain.com` bhi khulti hai
- [ ] Address bar mein **🔒 lock** nazar aata hai (SSL)
- [ ] Home page ki saari photos dikhti hain
- [ ] Shop page par saare products dikhte hain
- [ ] Filters aur search kaam karte hain
- [ ] Product par click karne se detail page khulta hai
- [ ] Size badalne se price badalti hai
- [ ] **Add to Cart** kaam karta hai, cart ka number barhta hai
- [ ] Cart mein quantity barhana/ghatana kaam karta hai
- [ ] Coupon `STITCH10` lagta hai aur discount dikhta hai
- [ ] Checkout form khali chhorne par error dikhata hai
- [ ] **Confirm Order se WhatsApp khulta hai aur order aap ke number par aata hai** ★
- [ ] Thank-you page par reference number dikhta hai
- [ ] Contact form ka message WhatsApp par aata hai
- [ ] Floating WhatsApp button (neeche kone mein) kaam karta hai
- [ ] Footer ke saare links khulte hain
- [ ] **Mobile par** poori website theek dikhti hai
- [ ] Google Search Console par sitemap submit kiya
- [ ] Google Business Profile bana liya

### Business ke liye tayyari

- [ ] WhatsApp Business app install kiya (catalogue + auto-reply milta hai)
- [ ] WhatsApp par greeting message set kiya
- [ ] Courier company se rate tay kiye (TCS / Leopards / M&P / Trax)
- [ ] Packing material le liya
- [ ] Warranty card / invoice ki parchi chhpwa li
- [ ] Instagram aur Facebook page bana liya, bio mein website ka link dala

---

## Mubarak ho — aap ka store tayyar hai

Aap ke paas ek **poori professional e-commerce website** hai:

- **12 pages** — home, shop, product detail, cart, checkout, thank-you, about, FAQ,
  contact, shipping, privacy, 404
- **27 products** with size options, features, specifications
- **35 photos** — sab optimize ki hui
- **Poora cart aur order system** WhatsApp ke saath jura hua
- **SEO tayyar** — sitemap, meta tags, sab kuch
- **Total size sirf 3.6 MB** — kisi bhi sasti hosting par tez chalegi
- **Monthly koi kharcha nahi** — bas saal ka domain + hosting

### Yaad rakhne ki 3 baatein

1. **Sirf `assets/js/products.js` edit karni hai** — 95% kaam usi mein hota hai
2. **Edit karne se pehle backup lein** — hamesha
3. **Tabdeeli na dikhe to Ctrl + Shift + R** — cache ka masla hai, website theek hai

### Sab se pehla kaam

> **`assets/js/products.js` kholein aur `whatsapp: "923001234567"` ko apne asli
> number se badal dein.** Ye ek line hi aap ke orders ka darwaza hai.

Kaamyabi ki dua. Aap ka business khoob chale. 🧵

---

*Eleventh Stitch — Sleep, Stitched Right*
